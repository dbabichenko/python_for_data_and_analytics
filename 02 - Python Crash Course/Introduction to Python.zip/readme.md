# Introduction to Python




## Topics

* Jupyter Notebooks - what are they? Why use them? showing your work. Reproducibility. code cells. executing code. brief markdown.  Ect. (Matt)
* Demonstration with federalist papers - show what you can do with Python, computing, autmation. Why would you want to do this...because counting words by hand is hard.
* Variables and datatypes - ints, floats, strings, booleans. mathematical operations. importing libraries. typecasting. tab completion
* Control flow - if, else, elif
* Collections & Sequence data types - containg data with other dataypes. Lists, Dictionaries. sets?
* Loops - For loops. range and itemset. iterating through lists. iterating through dictionaries
* Code Reuse - calling fuctions and methods, parameters positional and named, return values, and defining function. shift-tab for documetation in Jupyter 
* Working with files - open/close. read/write. CSV reader.






### Python Sugar
* list comprehensions
* with open 