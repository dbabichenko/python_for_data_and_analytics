# Diving Into the Notebook

- The Python Data Science Ecosystem
- What is the Jupyter Notebook
- Notebook Basics
- Running Code
- Markdown Cells